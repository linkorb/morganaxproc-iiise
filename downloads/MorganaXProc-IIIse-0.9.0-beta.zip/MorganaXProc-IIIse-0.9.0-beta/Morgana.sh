#!/bin/bash

java -jar -javaagent:MorganaXProc-IIIse_lib/quasar-core-0.7.9.jar MorganaXProc-IIIse.jar $@
