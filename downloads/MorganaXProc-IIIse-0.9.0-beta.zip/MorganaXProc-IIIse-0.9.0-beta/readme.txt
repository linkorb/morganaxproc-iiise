MorganaXProc-IIIse
Version:	0.9.0-beta
Copyright:	Copyright 2011-2020 by <xml-project /> Achim Berndzen

This version is for Java 8 ONLY!
================================

For more information please see:
	https://www.xml-project.com/MorganaXProc-III